export const SELECT_STYLE_DEFAULT = 0;
export const SELECT_STYLE_LANGUAGE = 1;
export const DEFAULT_LOCALE = "en";
export const SUPPORTED_LOCALES = ['en', 'da', 'de'];
