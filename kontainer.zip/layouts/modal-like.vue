<template>
	<div>
		<div class="modal-like">
			<nuxt/>
		</div>
	</div>
</template>

<script>

export default {
	components: {
	},
	props: ['modal-like'],
};
</script>

<style scoped lang="scss">
</style>
