<template>
    <NuxtPage />
</template>
