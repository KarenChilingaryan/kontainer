git pull
yarn install
yarn run build
sudo pm2 restart www
