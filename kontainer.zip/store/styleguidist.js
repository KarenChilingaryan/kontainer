
import createStore from './index';


export default createStore();
